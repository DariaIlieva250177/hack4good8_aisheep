# Build the mobile UI for the AI Sheep expert app (UI only)

We are team AI Sheep at Hackathon for Good #8, working on the ACAPS "Ground Truth" challenge. ACAPS publishes humanitarian risk analyses. Our app lets a small, trusted panel of humanitarian experts (5 to 10 per country) react to those analyses and forecast how risks develop, a few minutes at a time, while each expert controls their own anonymity.

Build the **mobile UI only**, with mock data. We will connect the backend later, so keep all data behind a thin layer we can swap out. Desktop comes later.

## 0. Before you write code

1. Read `README.md`, `CLAUDE.md`, `docs/challenge-brief.md` and `docs/data-dictionary.md` if they exist in this repo.
2. Open every image in `docs/design/` (listed in section 2). `wireframes.png` and `flows.png` are the source of truth for layout and navigation.
3. List the files in `UI_Images/` and tell me how you will map each one to a risk family (section 5). Ask me about any file name you can't place.
4. Check whether the repo already has a front end. If it does, use its framework. If not, create `frontend/` with React, Vite and TypeScript.
5. Only add these dependencies unless you ask me first: `react-router-dom`, `motion` (the library formerly called framer-motion), `lucide-react`, `@fontsource-variable/bricolage-grotesque`, `d3-geo`, `topojson-client`, `world-atlas`.
6. Show me a short plan (folders, components, order of screens). Then build one screen at a time, run the dev server, check the screen at 390 × 844, and commit after each screen.

## 1. Product rules that shape every screen

- **Experts are busy.** Each screen supports one quick action. Nothing should need a long session.
- **Anonymity builds trust.** Each expert picks exactly one level: name visible to other experts, pseudonym, or fully anonymous. Contributions are never shown to the public.
- **No real photos of people anywhere.** Use pseudonyms and generated avatars (initials or abstract shapes). This also applies to the profile and notification screens, where the wireframes still show template photos.
- **Independent answers first.** An expert sees other experts' answers only after giving their own. This keeps the group from copying each other (Delphi method).
- **It must not feel like a chatbot.** No chat bubbles, no AI sparkle icons, no assistant persona.
- **Quality over engagement.** The ranking rewards accuracy, not time in the app. No confetti, no streaks.
- **Synthetic data only.** No real personal data.

## 2. Design references in `docs/design/`

| File | Take from it | Leave out |
|---|---|---|
| `wireframes.png` | The 9 screens and their layout | Placeholder text and photos |
| `flows.png` | Navigation between screens | — |
| `inspo-metallic.png` | Glossy chrome 3D shapes (section 6.4) | The saturated electric blue as the main UI colour |
| `inspo-space-map.png` | The dark space mood and glowing Earth, for the contributions map on Ranking; glass buttons on dark | Astronaut imagery |
| `inspo-glass-tabs.png` | Frosted glass tabs and cards | The purple (in ACAPS's palette purple means severity) and the anime imagery |
| `inspo-waves.png` | One frame of the waves animation (section 6.3) | The heart-rate content |

The waves come from a video, so here is the motion: on a dark navy background, a ring of fine red strands made of thousands of tiny particles slowly swirls and changes shape around a central number, like silk or smoke in slow motion.

## 3. Design tokens

Put these in `src/styles/tokens.css` as CSS variables.

### Colours

| Token | Hex | Use |
|---|---|---|
| `--ink` | `#000000` | Main text |
| `--ink-2` | `#4f5a63` | Secondary text on the soft ground |
| `--acaps-dark` | `#004b78` | Primary buttons, ACAPS statements, active tab |
| `--acaps-blue` | `#0096ba` | The "you" marker only (selected answer dot, your map lights, your avatar ring). Icons and large text only: it is 3.5:1 on white |
| `--highlight` | `#d8d800` | "New since last round" only, as a background behind dark text (unread rows at 12% opacity) |
| `--ground` | `#e4e8eb` | Soft (neumorphic) page and card surface |
| `--night` | `#001f33` | Ranking screen background |
| `--line` | `#c9ced2` | Dividers |

Risk level ramp. Red means risk level and nothing else: never use it for errors or delete buttons.

| Level | Background | Text on it |
|---|---|---|
| High | `#b8163c` | `#ffffff` (6.5:1) |
| Medium | `#d97a8c` | `#3d0613` (5.8:1) |
| Low | `#efc3cc` | `#5c0a1e` (8.8:1) |

Never use orange or purple anywhere: ACAPS uses them for access constraints and severity.

### Risk families

Each risk belongs to one family. The family sets the image, a pale tint behind the image and the colour of the family chip.

| Family | Tint | Label colour |
|---|---|---|
| Conflict | `#e8e6d6` | `#5f5c36` |
| Political | `#e3e7ee` | `#475670` |
| Economic | `#f3ead2` | `#7a5c17` |
| Hydrometeorological | `#deeaf1` | `#2f6385` |
| Geophysical | `#ede4dc` | `#664e3c` |
| Environmental | `#e2ece0` | `#43623f` |
| Technological | `#e5e6e8` | `#4d5257` |
| Health | `#dcede9` | `#285f58` |
| Fallback | none | `#4f5a63` |

### Typography

- Font: Bricolage Grotesque, self-hosted through `@fontsource-variable/bricolage-grotesque`. Use the variant that includes the width (`wdth`) axis. Don't load fonts from Google: a request to a third party can expose experts in sensitive contexts.
- Two voices:
  - **ACAPS voice**: normal width, weight 400 to 500. Risk titles, data, labels, buttons.
  - **Expert voice**: `font-stretch: 75%`, weight 600, only at 24 px and above. Questions to the expert and quotes of expert answers.
- Mobile sizes: question heading 40, expert quote 24, risk title 20, body 16, UI text 16, small 14. Use only these.
- Weights 400, 500 and 600 only. `font-optical-sizing: auto`. Tabular figures for all numbers. Sentence case everywhere.

### Surfaces

- **Soft (neumorphic)** for content cards and their controls. The card is the same colour as the ground.
  - Card: `box-shadow: 18px 18px 36px #c3c9ce, -18px -18px 36px #ffffff`, radius 32.
  - Raised control: `6px 6px 12px #c3c9ce, -6px -6px 12px #ffffff`, radius 16 (pills 999).
  - Pressed control: `inset 5px 5px 10px #c3c9ce, inset -5px -5px 10px #ffffff`.
- **Glass** for anything floating above content: the tab bar, filter tabs, overlays on images and on the map.
  - Light: `background: rgba(255,255,255,0.6); backdrop-filter: blur(20px) saturate(150%); border: 1px solid rgba(255,255,255,0.85)`.
  - Dark (Ranking): `background: rgba(0,36,60,0.72)`, same blur, `border: 1px solid rgba(255,255,255,0.22)`.
  - Add the `-webkit-backdrop-filter` prefix.
- **Metallic** is decorative only (section 6.4).

### Accessibility

- Text at least 4.5:1, large text and icons at least 3:1, touch targets at least 44 px.
- Visible focus ring: `2px solid #0096ba`, offset 2 px.
- Primary actions are always solid (`--acaps-dark` background, white text), never glass or soft-only.
- A selected state never relies on shadow alone. Also change the text colour to `--acaps-dark`, use weight 600 and show an 8 px `--acaps-blue` dot.

## 4. Data layer

- `src/data/types.ts`: `Risk { id, title, country, type, level: 'Low' | 'Medium' | 'High', probability: 'Very Low' | 'Low' | 'Medium' | 'High' | 'Very High', impact: 1..5, exposure: string, status, family, image }`, plus types for users, answers, notifications and ranking.
- `src/data/api.ts`: async functions (`getRisks`, `getTodo`, `getCommunities`, `getTopic`, `submitAnswer`, `getRanking`, `getNotifications`) that return mock data now and real data later.
- `src/data/mock.ts`: use these real ACAPS risks. Copy the fields from `data/risk-radar-export.csv` if it exists; otherwise use the values below.

| ID | Title | Country | Level | Probability | Impact | Exposure | Family |
|---|---|---|---|---|---|---|---|
| R1043 | Escalating cross-border insecurity linked to the Sudan conflict increases protection risks and humanitarian needs in eastern Chad | Chad | High | High | 4 | >500,000 | Conflict (border image) |
| R1066 | Escalating insecurity across the Lake Chad Basin increases displacement, protection risks, and humanitarian access constraints | Chad, Niger, Cameroon, Nigeria | High | Very High | 4 | 100,000-250,000 | Conflict |
| R1055 | Mass returns from eastern Chad exacerbate humanitarian needs in West Darfur State | Sudan | Medium | Medium | 3 | 100,000-250,000 | Conflict (displacement image) |
| R1051 | Interregional trade restrictions disrupt markets and deepen food insecurity in West Kordofan | Sudan | Medium | Medium | 5 | 250,000-500,000 | Economic |
| R1054 | RSF drone attacks damage the Merowe Dam and power grid in Northern state, disrupting health, food security, and public services | Sudan | Medium | Low | 5 | 250,000-500,000 | Technological |
| R1045 | Forecast below-average Kiremt rains in Ethiopia threaten food production and livelihoods | Ethiopia | High | High | 4 | >500,000 | Hydrometeorological (drought image) |

All six are active. R1045 is a "New emerging risk"; the others are "Marked deterioration in an existing crisis".

The export has **no hazard category column** (its "Risk Type" field is the risk type above). `family` is our own tag, so set it by hand in `mock.ts`.

For everything else (users, answers, counts, rankings, notifications), invent clearly synthetic data. The demo expert is "Kestrel" on the Chad panel.

## 5. Risk images

- The source images are in `UI_Images/` in the repo root. Don't edit or move them. Copy them to `frontend/public/risk-images/` and map each to a family in `src/data/families.ts`. Any risk without a match uses the fallback image.
- **Blend the image into the card** rather than framing it:
  - No border and no radius. The image runs the full card width from the card's top edge.
  - `mix-blend-mode: multiply`, so the image's white background takes on the card's colour.
  - Fade all four edges with this mask, plus the `-webkit-` versions:
    `mask-image: linear-gradient(to bottom, transparent 0%, #000 18%, #000 62%, transparent 100%), linear-gradient(to right, transparent 0%, #000 14%, #000 86%, transparent 100%); mask-composite: intersect;`
  - Behind the image, add a layer in the family tint with `mask-image: radial-gradient(ellipse 62% 64% at 50% 52%, #000 40%, transparent 100%)`.
- **Optional duotone.** Add a constant `IMAGE_TREATMENT: 'original' | 'duotone'` in `src/config.ts`, defaulting to `'original'`. Duotone is an inline SVG filter per family:
  - `feColorMatrix` to greyscale with weights R 0.15, G 0.35, B 0.5. The blue weighting keeps skies lighter than sand.
  - `feComponentTransfer` mapping dark to the family label colour (darkened about a third), then the label colour, then the tint, then `#fbfaf6` for the lightest tones.

## 6. Components

### 6.1 RiskCard (soft)

From top to bottom:
1. The blended image.
2. A row of chips:
   - level chip (risk ramp colours)
   - family chip (tint background, label-colour text, a 7 px dot in the label colour)
   - area chip (raised soft pill)
   - risk ID aligned right
3. The risk title in the ACAPS voice, `--acaps-dark`.
4. The question "Do you recognise this picture?" in the expert voice.
5. Three soft buttons: Yes, Partly, No. The selected one is pressed (section 3) and uses `aria-pressed`.
6. An action row: "Add a note" (raised soft), "Send answer" (solid, primary) and "5 of 7 answered" in small text.
7. A footer: a user icon in `--acaps-blue`, "Peers see you as Kestrel" and a "Change" link that goes to the privacy section of Profile.

### 6.2 Card stack with swipe

- The front card is draggable with `motion`.
  - **Swipe right** = "Answer later": the risk moves to To-do.
  - **Swipe left** = "Skip, I can't answer this": the risk is removed, with an Undo toast for 5 seconds.
- Show the action label on the card while dragging.
- Two back cards peek out behind, rotated ±6°, like a fan.
- Below the stack, add visible "Later" and "Skip" buttons, so people who can't swipe (keyboard, screen reader, motor impairments) can still do both.

### 6.3 RiskWaves

- Marks very high risk topics, which means risks with probability **Very High** (R1066 in the mock data).
- A canvas animation of fine red (`#b8163c`) particle strands swirling slowly in a ring, behind the image area of the card. Keep the opacity low enough that text stays readable. The multiply blend lets the strands show through the image's light areas.
- On list rows (To-do, Community), use a small static version next to the level chip instead.
- Rules:
  - Only one animated instance on screen at a time.
  - Pause when off-screen (`IntersectionObserver`), and cap at 30 fps.
  - With `prefers-reduced-motion`, show a single still frame.
  - In low-data mode, turn it off and show a "Very high probability" text badge instead.

### 6.4 MetalShape

- Glossy chrome shapes in ACAPS blues (`#004b78` to `#0096ba`, with white highlights).
- Use them for the login hero, the certificate badges on Ranking (instead of the laurel images in the wireframe) and empty states.
- Build an SVG placeholder with gradients and specular highlights. If image files exist in `UI_Images/shapes/`, use those instead.
- Decorative: `aria-hidden="true"`. Hide in low-data mode.

### 6.5 GlassTabBar

- A floating glass pill at the bottom with five items, each with an icon and a label:

| Label | Lucide icon | Note |
|---|---|---|
| Risks | `Layers` | — |
| To-do | `ListTodo` | — |
| Alerts | `Bell` | Unread count badge |
| Community | `Users` | — |
| Ranking | `Trophy` | — |

- The active item has a solid `--acaps-dark` icon and label; the others use `--ink-2`.
- Respect the safe-area inset at the bottom.

### 6.6 ContributionsMap (Ranking)

- An SVG globe built with `d3-geo` (`geoOrthographic`, centred near 20°E 10°N) and `world-atlas` 110m countries.
  - Ocean `#001f33`, land `#0b3550`, a faint graticule.
  - It should look like the glowing Earth in `inspo-space-map.png`.
- Each country the expert contributed to gets a glowing light in `--acaps-blue` fading to `#7fd3ea`, because blue means "you". Size the light by the number of contributions.
- Place lights only at country or region centroids, never at exact places. Which regions an expert knows well can identify them, and exact points can expose communities.
- Below the map show:
  - "12 countries, 4 regions, 38 contributions"
  - "People living in the areas of risks you helped assess: [sum of the lower bounds of their exposure bands]", with a small note "Based on ACAPS exposure estimates".
- Don't claim lives saved or villages protected. We can't prove that, and ACAPS's credibility depends on not overclaiming.
- In low-data mode, replace the map with a plain list of countries and counts.

## 7. Screens (390 × 844 first)

1. **Log in**
   - A soft card with username and password fields (pressed/inset style).
   - A solid "Log in" button in `--acaps-dark`. Not `#0096ba`: white text on it fails contrast.
   - "Forgot password?" and "Sign up" links.
   - Above the card, a MetalShape hero. Below it, a curved fan of risk-image tiles, like the arc of cards in the wireframe.
   - Low-data: the form only.
2. **Risks** (home)
   - An avatar with the pseudonym's initials at top right, which opens Profile.
   - Short instruction: "Tap Yes, Partly or No. Swipe right to answer later, left to skip."
   - The card stack (6.2), then the tab bar.
3. **Profile**
   - Back button and the title "Profile".
   - Identity card: generated avatar, "Kestrel" and "Chad panel". No email address and no photo.
   - **Account:** Manage profile, Password and security, Notifications, Language (English).
   - **Preferences:** About us, Theme (Light only for now), Low-data mode (Auto / On / Off).
   - **Privacy:** "Show my name to other experts", "Use a pseudonym" and "Stay anonymous", styled as toggles but **mutually exclusive**: exactly one is on, like a radio group. Helper text: "Whatever you choose, nothing you write is ever shown to the public."
4. **To-do**
   - Two groups: "Urgent" for High-level risks and "Moderate" for Medium-level risks.
   - Header pills use the risk ramp, not yellow: yellow means "new", and white text on it fails contrast.
   - Each row: a small blended thumbnail, the title cut off after two lines, and a thin level-colour edge.
   - Tapping a row opens Answer detail.
5. **Community**
   - Two sections, "Your communities" and "Other communities", with rows like To-do.
   - Each row shows the member count and an unread marker using `--highlight`.
   - Tapping a row opens Community topic.
6. **Community topic**
   - A compact risk header: image, chips, title and question.
   - A "Your answer" box.
   - Other experts' answers, each with pseudonym, generated avatar and text.
   - Until the user has answered, hide the other answers behind a soft locked panel: "Answer first to see how 6 others answered. This keeps everyone's view independent."
7. **Ranking** (dark, `--night`)
   - A dark glass card "Your ranking": "#3 of 9 on the Chad panel", plus a countdown to the end of the round (days, hours, minutes, seconds).
   - Certificates: three MetalShape badges, for example "First resolved forecast", "10 contributions" and "Well calibrated".
   - The ContributionsMap (6.6).
   - A 2 × 2 grid of glass stat tiles: Contributions 38, Resolved forecasts 16, Accuracy (Brier) 0.18 with "ACAPS baseline 0.21", Rounds joined 24.
   - All values are synthetic examples.
8. **Answer detail**
   - A compact risk header.
   - "Your detailed answer": a textarea that grows with the text.
   - "Add sources or articles" with a + button that adds URL fields (validate them).
   - A solid "Submit" button. After submitting, show a toast ("Sent. You'll see the group's view when the round closes.") and return to Risks.
9. **Notifications**
   - Back button and the title "Notifications".
   - Rows with system icons, never photos. Examples:
     - "New ACAPS analysis for Chad: 2 risks to review"
     - "Round 2 is open for R1043"
     - "Group summary ready for R1066"
     - "Your forecast on R1045 has resolved"
     - "A peer replied in Lake Chad Basin"
   - Unread rows use `--highlight` at 12% opacity. Tapping a row opens the screen it refers to.

## 8. Navigation (see `flows.png`)

- Log in leads to Risks.
- The avatar at top right opens Profile from any tab, and back returns to where you were.
- The tab bar switches between Risks, To-do, Alerts, Community and Ranking.
- From Risks:
  - "Add a note" opens Answer detail.
  - Swiping right adds the risk to To-do.
- From To-do, a row opens Answer detail; submitting there returns to Risks.
- From Community, a row opens Community topic.
- From Notifications, each row opens the screen it refers to.

Use `react-router-dom` with one route per screen.

## 9. Rich mode and low-data mode

- Put `data-mode="rich"` or `data-mode="lite"` on `<html>`, and key all CSS off it.
- **Start in lite**, so the first screen renders fast. Then decide whether to upgrade:
  - If `navigator.connection` exists, upgrade unless `saveData` is true or `effectiveType` is `slow-2g`, `2g` or `3g`.
  - Otherwise (Safari, Firefox), time a small request and upgrade only if it finished in under 1 second.
  - Load the rich assets in the background and switch only when they're ready, never while someone is typing.
- The Low-data mode setting in Profile (Auto / On / Off) always wins. Store it in `localStorage` under the key `lowData`.
- **Lite mode:**
  - System font stack. Don't load Bricolage, and carry the two voices by weight only: 600 for the expert, 400 for ACAPS.
  - No images, no blur, no waves, no metal shapes, and the map becomes a list.
  - Every piece of content and every action stays available.
- **`prefers-reduced-motion`:** no swipe animation (cards move instantly) and still waves.

## 10. Structure and code quality

- `src/styles/tokens.css`, `src/components/`, `src/screens/`, `src/data/`.
- Put all UI text in `src/i18n/en.ts` (French and Arabic come later).
- Use CSS logical properties (`margin-inline-start` and so on) so right-to-left Arabic works later.
- Semantic HTML: real `<button>` elements, lists as `<ul>`, headings in order, alt text on images describing the illustration, `aria-pressed` on toggles.
- No `localStorage` except the `lowData` setting.

## 11. Out of scope for now

Backend, real authentication, real data fetching, the desktop layout, dark theme, translations and the ACAPS moderator view.

## 12. Done when

- All 9 screens are reachable through the flows at 390 × 844, with no sideways scrolling.
- Swiping and the "Later" / "Skip" buttons both work.
- Switching Low-data mode visibly changes the app, and every action still works in it.
- Each screen has its own commit with a clear message.
